"use client"; // This directive marks the file as a Client Component

import React, { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation"; // Import useRouter and usePathname

// Import client-side auth helpers from the standalone file
// Assuming src/lib/auth-client.ts exists and contains these functions
import {
  isAuthenticated,
  removeAuthToken,
  getUserId,
} from "../lib/auth-client";

// Direct imports for all components, bypassing barrel files
import Header from "../components/Header/Header";
import PageContainer from "../components/Layout/PageContainer";
import SmartSearch from "../components/Sidebar/SmartSearch";
import PreferenceForm from "../components/Sidebar/PreferenceForm";
import GenerateButton from "../components/Sidebar/GenerateButton";
import ItineraryPanel from "../components/MainPanel/ItineraryPanel";
import MapView from "../components/MainPanel/MapView";
import FloatingActions from "../components/Controls/FloatingActions";

const App: React.FC = () => {
  const router = useRouter();
  const pathname = usePathname(); // Get current pathname
  const [isAuth, setIsAuth] = useState(false); // State to track authentication status
  const [currentUserId, setCurrentUserId] = useState<string | null>(null); // State to store current user ID

  // Check authentication status on component mount
  useEffect(() => {
    const authenticated = isAuthenticated();
    setIsAuth(authenticated);
    if (authenticated) {
      setCurrentUserId(getUserId());
    } else {
      setCurrentUserId(null);
    }
  }, []);

  // Redirect to login if not authenticated and trying to access main app
  useEffect(() => {
    // Only redirect if not authenticated AND not already on an auth page
    if (!isAuth && !pathname.startsWith("/auth")) {
      router.push("/auth/login");
    }
  }, [isAuth, pathname, router]);

  // State for user preferences
  const [preferences, setPreferences] = useState({
    destination: "",
    travelStartDate: "",
    travelEndDate: "",
    budget: 15000,
    travelers: "2",
    travelType: ["history", "nature"], // Default selected types
    accommodation: "comfort",
    transportation: ["train"], // Default selected transportation
    activityIntensity: "moderate",
    specialNeeds: [],
  });
  // State for smart search input query
  const [smartSearchQuery, setSmartSearchQuery] = useState(
    "Tell me what kind of trip you want... e.g., Beach hiking July Europe"
  );

  // State for AI-generated itinerary
  const [itinerary, setItinerary] = useState<any[]>([]);
  // State for loading indicator
  const [isLoading, setIsLoading] = useState(false);

  // Handler for preference changes
  const handlePreferenceChange = (key: string, value: any) => {
    setPreferences((prev) => ({ ...prev, [key]: value }));
  };

  // Handler for smart search
  const handleSmartSearch = (query: string) => {
    console.log("Smart search query:", query);
    setPreferences((prev) => ({ ...prev, destination: query }));
  };

  // Function to handle AI itinerary generation
  const handleGenerateItinerary = async () => {
    setIsLoading(true);
    console.log("Generating itinerary with current preferences:", preferences);

    try {
      const token = localStorage.getItem("authToken"); // Get token from localStorage
      if (!token) {
        alert("请先登录以生成行程。");
        router.push("/auth/login");
        return;
      }

      const response = await fetch("/api/generate-itinerary", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, // Send the token
        },
        body: JSON.stringify({ preferences }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Failed to generate itinerary:", errorData);
        alert(`生成行程失败: ${errorData.error || response.statusText}`);
        setIsLoading(false);
        return;
      }

      const generatedItinerary = await response.json();
      setItinerary(generatedItinerary); // Update itinerary state
      console.log("Generated Itinerary:", generatedItinerary);
    } catch (error) {
      console.error("Error calling generate-itinerary API:", error);
      alert("生成行程时发生错误。");
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const handleLogout = () => {
    removeAuthToken(); // Remove token from localStorage
    setIsAuth(false); // Update auth state
    setCurrentUserId(null); // Clear user ID
    router.push("/auth/login"); // Redirect to login page
  };

  // Keyboard shortcuts (remains in App.tsx as it's global)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "s":
            e.preventDefault();
            alert("Save feature under development...");
            break;
          case "f":
            e.preventDefault();
            const searchInput = document.querySelector(
              ".search-input"
            ) as HTMLInputElement;
            if (searchInput) searchInput.focus();
            break;
        }
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Simulate real-time weather update (moved from ItineraryPanel to App for centralized control)
  const [weatherData, setWeatherData] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    const updateWeather = () => {
      const weatherOptions = ["晴天", "多云", "小雨", "阴天"];
      const tempOptions = ["25°C", "26°C", "27°C", "28°C", "29°C", "30°C"];
      const newWeatherData: { [key: string]: string } = {};

      itinerary.forEach((day) => {
        const randomWeather =
          weatherOptions[Math.floor(Math.random() * weatherOptions.length)];
        const randomTemp =
          tempOptions[Math.floor(Math.random() * tempOptions.length)];
        newWeatherData[day.date] = `${randomWeather} ${randomTemp}`;
      });
      setWeatherData(newWeatherData);
    };

    updateWeather();
    const interval = setInterval(updateWeather, 30000);
    return () => clearInterval(interval);
  }, [itinerary]);

  // Add touch device support (passive listeners)
  useEffect(() => {
    if ("ontouchstart" in window) {
      document.addEventListener("touchstart", () => {}, { passive: true });

      const cards = document.querySelectorAll(
        ".activity-card, .type-card, .suggestion-tag"
      );
      cards.forEach((card) => {
        card.addEventListener(
          "touchstart",
          function () {
            (this as HTMLElement).style.transform = "scale(0.98)";
          },
          { passive: true }
        );

        card.addEventListener(
          "touchend",
          function () {
            (this as HTMLElement).style.transform = "";
          },
          { passive: true }
        );
      });
    }
  }, []);

  // Content for the sidebar
  const sidebarContent = (
    <div className="flex flex-col h-full">
      {/* SmartSearch component now expects `query` and `setQuery` props */}
      <SmartSearch
        query={smartSearchQuery}
        setQuery={setSmartSearchQuery}
        onSearch={handleSmartSearch}
        onSuggestionClick={(s) => setSmartSearchQuery(s)}
      />
      <PreferenceForm
        preferences={preferences}
        onPreferenceChange={handlePreferenceChange}
      />
      <GenerateButton onClick={handleGenerateItinerary} isLoading={isLoading} />
    </div>
  );

  // Content for the main panel (itinerary and map displayed simultaneously)
  const mainPanelContent = (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
      {/* ItineraryPanel component now expects `weatherData` prop */}
      <ItineraryPanel itinerary={itinerary} weatherData={weatherData} />
      <MapView />
    </div>
  );

  // Conditionally render the main App content based on authentication
  // If not authenticated AND not on an auth page, return null to allow redirection
  if (!isAuth && !pathname.startsWith("/auth")) {
    return null; // Or a loading spinner if you prefer
  }

  return (
    <div className="App">
      {/* Pass onLogout, currentUserId, and pathname to PageContainer */}
      <PageContainer
        sidebar={sidebarContent}
        mainContent={mainPanelContent}
        onLogout={handleLogout}
        currentUserId={currentUserId}
        pathname={pathname}
      />
      <FloatingActions />
    </div>
  );
};

export default App;

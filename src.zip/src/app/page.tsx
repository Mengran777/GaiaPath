"use client"; // This directive marks the file as a Client Component

import React, { useEffect } from "react";
import { useRouter } from "next/navigation"; // Import useRouter
import App from "./App"; // Adjust the import path based on where your App.tsx is located
import { isAuthenticated } from "@/lib/auth-client"; // Import client-side auth helper

/**
 * This is the main page component for your Next.js application.
 * It serves as the entry point for the root route ('/').
 * It conditionally renders the core 'App' component based on authentication status.
 */
const HomePage: React.FC = () => {
  const router = useRouter();

  useEffect(() => {
    // If not authenticated, redirect to the login page
    if (!isAuthenticated()) {
      router.push("/auth/login");
    }
  }, [router]);

  // If authenticated, render the main App component
  if (isAuthenticated()) {
    return <App />;
  }

  // Otherwise, return null or a loading indicator while redirecting
  return null; // Or a loading spinner
};

export default HomePage;

export { default as Input } from "./Input";
export { default as Select } from "./Select";
export { default as Slider } from "./Slider";
export { default as Tag } from "./Tag";
export { default as TypeCard } from "./TypeCard";
